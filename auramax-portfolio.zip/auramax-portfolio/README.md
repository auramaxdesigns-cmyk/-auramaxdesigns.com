# Auramax Designs — Portfolio Website

A minimal dark portfolio website for interior designer **Trevor Kiprono**, built with brutalist minimalism aesthetic principles.

## Overview

This portfolio showcases architectural and interior design projects with rich visuals, detailed case studies, awards recognition, and studio contact information. The design emphasizes material honesty, typographic authority, and radical simplicity.

## Design Philosophy

**Brutalist Minimalism** — The website combines the raw, honest aesthetic of brutalist architecture with contemporary web design principles. Every element serves a purpose; nothing is decorative.

### Color Palette
- **Concrete Gray (#3a3a3a)** — Primary background, representing raw materials
- **Pure White (#ffffff)** — Text and accents, creating stark contrast
- **Warm Wood (#8b6f47)** — Accent color for interactive elements, representing warmth and craftsmanship

### Typography
- **Headings:** Georgia / Garamond (serif) — Creates gravitas and authority
- **Body Text:** System fonts (sans-serif) — Clean, readable, contemporary

## Project Structure

```
auramax-portfolio/
├── index.html              # Main homepage
├── project-kitchen.html    # Case study: Luxury Kitchen
├── project-bedroom.html    # Case study: Master Bedroom
├── project-lobby.html      # Case study: Commercial Lobby
├── styles.css              # Main stylesheet
├── case-study.css          # Case study page styling
├── script.js               # Interactive features
├── ideas.md                # Design direction document
└── README.md               # This file
```

## Features

### Homepage
- **Hero Section** — Full-screen dramatic image with firm name and tagline
- **Project Grid** — Asymmetrical layout showcasing featured projects
- **Awards & Publications** — Recognition and media mentions
- **Contact Footer** — Studio location, email, phone, and social links

### Project Pages
Each case study includes:
- Full-screen hero image
- Project overview and design concept
- Key features and design elements
- Materials and specifications table
- Spatial experience description
- Outcome and impact

### Interactive Elements
- Sticky navigation header
- Smooth scroll transitions
- Hover effects on project cards
- Fade-in animations on scroll
- Responsive design (mobile, tablet, desktop)

## Customization Guide

### Updating Project Information

#### 1. Homepage Projects
Edit `index.html` in the projects section:
```html
<article class="project-card project-card-large">
    <div class="project-image">
        <img src="YOUR_IMAGE_URL" alt="Project Title">
    </div>
    <div class="project-info">
        <h3>Project Title</h3>
        <p class="project-meta">Project Type / Year</p>
        <p class="project-description">Description...</p>
        <a href="project-page.html" class="project-link">Explore the project</a>
    </div>
</article>
```

#### 2. Awards & Publications
Update the awards section in `index.html`:
```html
<div class="award-item">
    <h4>Award Title</h4>
    <p class="award-year">2024</p>
    <p class="award-org">Organization Name</p>
</div>
```

#### 3. Contact Information
Update footer links in `index.html`:
```html
<a href="mailto:your-email@example.com">your-email@example.com</a>
<a href="tel:+254123456789">+254 (0) 123 456 789</a>
```

### Adding New Project Pages

1. Create a new HTML file (e.g., `project-new.html`)
2. Copy the structure from an existing project page
3. Update the project title, images, and content
4. Add a link to the new project in the homepage project grid

### Changing Colors

Edit the CSS variables in `styles.css`:
```css
/* Update these hex codes */
background-color: #3a3a3a;  /* Concrete Gray */
color: #ffffff;              /* Pure White */
color: #8b6f47;              /* Warm Wood */
```

### Updating Images

Replace image URLs in HTML files with your own project images:
```html
<img src="https://your-image-url.jpg" alt="Project Description">
```

## Responsive Design

The website is fully responsive and adapts to all screen sizes:
- **Desktop** (1200px+) — Full layout with multi-column grids
- **Tablet** (768px-1199px) — Adjusted layouts and spacing
- **Mobile** (< 768px) — Single-column layout, optimized touch targets

## Browser Compatibility

The website works on all modern browsers:
- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Optimization

- Optimized images for web
- Minimal CSS and JavaScript
- Smooth animations using CSS transforms
- Lazy loading support for images

## Deployment

To deploy this website:

1. **Static Hosting** (Recommended)
   - Upload all files to Netlify, Vercel, GitHub Pages, or similar
   - No server-side processing required

2. **Self-Hosted**
   - Copy files to your web server
   - Ensure proper MIME types for CSS and JavaScript

3. **Local Testing**
   - Run a local server: `python3 -m http.server 8000`
   - Open `http://localhost:8000` in your browser

## Customization Tips

### Adding More Projects
1. Create new case study pages following the existing template
2. Add project cards to the homepage grid
3. Maintain consistent styling and layout

### Extending the Design
- Add more sections (e.g., Team, Process, Services)
- Create additional pages (e.g., About, Blog)
- Integrate contact forms or newsletter signup

### SEO Optimization
- Update meta descriptions in each HTML file
- Add structured data (JSON-LD) for projects
- Optimize image alt text
- Create a sitemap.xml

## Support & Maintenance

For questions or issues:
1. Review the design philosophy in `ideas.md`
2. Check CSS comments for styling guidance
3. Ensure all image URLs are accessible
4. Test across different browsers and devices

## License

This website design is custom-built for Auramax Designs. All content and design elements are proprietary.

---

**Created with Brutalist Minimalism principles**
*Thoughtful spaces crafted with precision*
