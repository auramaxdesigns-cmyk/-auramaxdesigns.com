# Quick Start: Deploy to Netlify in 5 Minutes

Follow these simple steps to get your Auramax Designs portfolio live.

## What You'll Need

- GitHub account (free)
- Netlify account (free)
- Your portfolio files (already prepared!)

## The 5-Minute Process

### Step 1: Create GitHub Repository (1 minute)

1. Go to [github.com/new](https://github.com/new)
2. Name it: `auramax-portfolio`
3. Click **Create repository**
4. Click **Add file** → **Upload files**
5. Drag and drop all your portfolio files
6. Click **Commit changes**

### Step 2: Connect to Netlify (2 minutes)

1. Go to [netlify.com](https://netlify.com)
2. Click **Add new site** → **Import an existing project**
3. Choose **GitHub**
4. Find and select `auramax-portfolio`
5. Click **Deploy site**

### Step 3: Wait for Deployment (1 minute)

Netlify will automatically deploy your site. You'll see:
- Build log showing progress
- Green checkmark when complete
- Your live URL: `https://your-site-name.netlify.app`

### Step 4: Test Your Site (1 minute)

1. Visit your Netlify URL
2. Check homepage loads
3. Click a project to view details
4. Go to `/admin/` and log in:
   - Email: `hello@auramaxdesigns.com`
   - Password: `@auramaxdesigns`
5. Try editing a project

## Done! 🎉

Your site is now live and accessible worldwide!

---

## What's Included

Your deployed site has:

✓ **Homepage** with hero image and project grid
✓ **Project Pages** with detailed case studies
✓ **Admin Dashboard** to manage content
✓ **CMS** for easy updates
✓ **Contact Information** in footer
✓ **Awards & Publications** section
✓ **Responsive Design** for all devices
✓ **Free HTTPS** security

## Next Steps

### Share Your Site
- Send the Netlify URL to clients
- Post on social media
- Add to your resume/portfolio

### Keep It Updated
- Add new projects through admin dashboard
- Update contact information as needed
- Keep awards and publications current

### Optional: Custom Domain
1. Buy a domain (godaddy.com, namecheap.com, etc.)
2. In Netlify: **Site settings** → **Domain management**
3. Add your domain
4. Update DNS settings with your registrar
5. Your site will be at `yourdomain.com`

### Automatic Updates
Every time you update your GitHub repository, Netlify automatically redeploys your site. To update:

1. Make changes to your files
2. Upload to GitHub
3. Netlify deploys automatically (2-3 minutes)

## Troubleshooting

**Site shows 404?**
- Verify `netlify.toml` and `_redirects` files are uploaded

**Admin won't load?**
- Clear browser cache (Ctrl+Shift+Delete)
- Hard refresh (Ctrl+Shift+R)

**Images not showing?**
- Check image URLs are correct
- Verify they use HTTPS

**Need help?**
- Read the full guide: `NETLIFY-DEPLOYMENT.md`
- Visit: https://docs.netlify.com

---

## Your Deployment is Complete!

Your Auramax Designs portfolio is now live, secure, and ready to impress clients. 

**Live URL:** `https://your-site-name.netlify.app`

**Admin Access:** `/admin/`

**Admin Credentials:**
- Email: `hello@auramaxdesigns.com`
- Password: `@auramaxdesigns`

Congratulations! 🚀
