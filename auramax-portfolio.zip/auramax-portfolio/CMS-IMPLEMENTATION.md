# CMS Implementation Guide — Auramax Designs

## Quick Start

Your portfolio now includes a fully functional JSON-based CMS with an admin dashboard. Here's how to use it.

### Files Overview

```
auramax-portfolio/
├── admin/
│   ├── index.html          # Admin dashboard interface
│   ├── admin.css           # Dashboard styling
│   └── admin.js            # Dashboard functionality
├── data/
│   ├── projects.json       # Project data
│   ├── awards.json         # Awards & publications data
│   └── settings.json       # Site settings
├── index-dynamic.html      # Dynamic homepage (uses CMS)
├── project-dynamic.html    # Dynamic project page (uses CMS)
├── cms-loader.js           # Loads and renders CMS data
├── index.html              # Original static homepage
├── project-*.html          # Original static project pages
└── styles.css              # Shared styles
```

---

## How to Use the Admin Dashboard

### Accessing the Dashboard

1. Open your browser and navigate to: `http://your-domain.com/admin/`
2. You'll see the admin interface with navigation on the left

### Managing Projects

#### Add a New Project

1. Click **"+ Add New Project"** button
2. Fill in the project details:
   - **Project ID**: Unique identifier (e.g., `my-project-2024`)
   - **Title**: Project name
   - **Type**: Residential, Commercial, Mixed-Use, or Hospitality
   - **Year**: Completion year
   - **Description**: Short description (appears on homepage)
   - **Hero Image URL**: Full-size image for project page
   - **Grid Image URL**: Image for project grid on homepage
   - **Grid Size**: Large (2 columns) or Medium (1 column)
   - **Featured**: Check to show on homepage
   - **Overview**: Detailed project overview
   - **Design Concept**: Explanation of design approach
   - **Outcome**: Project results and impact

3. Click **"Save Project"**

#### Edit a Project

1. Find the project in the projects list
2. Click the **"Edit"** button
3. Update the fields you want to change
4. Click **"Save Project"**

#### Delete a Project

1. Find the project in the projects list
2. Click the **"Delete"** button
3. Confirm deletion

### Managing Awards

#### Add an Award

1. Go to the **"Awards & Publications"** section
2. Click the **"Awards"** tab
3. Click **"+ Add Award"**
4. Fill in:
   - **Award Title**: Name of the award
   - **Year**: Year received
   - **Organization**: Organization that gave the award
5. Click **"Save Award"**

#### Edit/Delete Awards

- Click **"Edit"** to modify an award
- Click **"Delete"** to remove an award

### Managing Publications

#### Add a Publication

1. Go to the **"Awards & Publications"** section
2. Click the **"Publications"** tab
3. Click **"+ Add Publication"**
4. Fill in:
   - **Article Title**: Title of the article
   - **Publication Name**: Name of the magazine/website
   - **Date**: Publication date (e.g., "March 2024")
5. Click **"Save Publication"**

#### Edit/Delete Publications

- Click **"Edit"** to modify a publication
- Click **"Delete"** to remove a publication

### Managing Site Settings

1. Go to the **"Settings"** section
2. Update any of these fields:
   - **Site Title**: Your studio name
   - **Tagline**: Your studio tagline
   - **Email**: Contact email
   - **Phone**: Contact phone number
   - **Location**: Studio city
   - **Region**: Studio region/country
   - **Logo URL**: Your logo image URL
   - **Instagram URL**: Your Instagram profile link
   - **LinkedIn URL**: Your LinkedIn profile link
3. Click **"Save Settings"**

---

## Image URLs

### Where to Host Images

You have several options for hosting your project images:

#### Option 1: Cloudinary (Recommended)
- **URL**: https://cloudinary.com
- **Free tier**: 25GB storage
- **Features**: Image optimization, automatic resizing
- **How to use**: Upload image, copy the URL, paste in admin dashboard

#### Option 2: Unsplash
- **URL**: https://unsplash.com
- **Cost**: Free
- **Features**: High-quality stock images
- **How to use**: Find image, copy URL, paste in admin dashboard

#### Option 3: Your Own Server
- Upload images to your web server
- Use the full URL (e.g., `https://your-domain.com/images/project.jpg`)

#### Option 4: Google Drive
- Upload image to Google Drive
- Right-click → Share → Get link
- Modify URL to: `https://drive.google.com/uc?export=view&id=FILE_ID`

#### Option 5: Dropbox
- Upload image to Dropbox
- Right-click → Share → Copy link
- Change `dl=0` to `dl=1` at the end of URL

### Image Best Practices

- **Size**: At least 1200px wide for best quality
- **Format**: JPG for photos, PNG for graphics
- **Optimization**: Use tools like TinyPNG to compress before uploading
- **Alt Text**: Always add descriptive alt text in the admin dashboard

---

## Data Storage & Backup

### How Data is Stored

Currently, the CMS stores data in:
1. **JSON files** in the `/data/` folder (primary)
2. **Browser localStorage** (temporary, for demo purposes)

### Backing Up Your Data

#### Manual Backup

1. Download the `/data/` folder from your server
2. Save it in a safe location on your computer
3. Do this regularly (weekly or after major updates)

#### Automated Backup

For production sites, consider:
- Using your hosting provider's backup service
- Setting up automated backups to cloud storage (AWS S3, Google Drive, etc.)
- Using version control (Git) to track changes

### Restoring Data

1. If you have a backup of the `/data/` folder:
   - Upload it to your server, replacing the current folder
   - Refresh the admin dashboard
   - Your data will be restored

---

## Switching Between Static and Dynamic Sites

### Using the Dynamic Version (CMS-Powered)

To use the CMS-powered dynamic site:

1. **Replace your homepage link** from `index.html` to `index-dynamic.html`
2. **Update project links** from `project-*.html` to `project-dynamic.html?id=PROJECT_ID`
3. **Access admin** at `/admin/`

### Using the Static Version (Original)

The original static files are still available:
- `index.html` — Original homepage
- `project-kitchen.html` — Original project pages
- `project-bedroom.html`
- `project-lobby.html`

You can use either version, or run both simultaneously.

---

## Troubleshooting

### Changes Not Appearing on Site

**Problem**: I updated a project in the admin dashboard, but the changes don't appear on the site.

**Solution**:
1. Clear your browser cache (Ctrl+Shift+Delete on Windows, Cmd+Shift+Delete on Mac)
2. Do a hard refresh (Ctrl+F5 or Cmd+Shift+R)
3. Check that the JSON files in `/data/` were updated
4. Check browser console for errors (F12 → Console tab)

### Images Not Loading

**Problem**: Images show as broken on the site.

**Solution**:
1. Verify the image URL is correct and accessible
2. Check that the image server allows cross-origin requests
3. Try a different image hosting service
4. Use a URL shortener if the URL is very long

### Admin Dashboard Not Loading

**Problem**: The admin dashboard page is blank or shows errors.

**Solution**:
1. Check that `/data/projects.json` exists and is valid JSON
2. Open browser console (F12) and check for error messages
3. Verify file permissions on the server
4. Try clearing browser cache and reloading

### Data Lost After Refresh

**Problem**: I made changes in the admin dashboard, but they disappeared after refreshing.

**Solution**:
- The current demo version stores data in browser localStorage
- For production, you need to implement backend saving
- See "Production Setup" section below

---

## Production Setup

### Current Limitations

The current CMS implementation stores data in:
- **JSON files** (primary storage)
- **Browser localStorage** (temporary, demo only)

### For Production, You Need:

1. **Backend Server** to save changes to JSON files
2. **Authentication** to protect the admin dashboard
3. **File Upload** capability for images
4. **Database** for larger scale operations

### Recommended Production Solutions

#### Option 1: Node.js + Express (Recommended)

```javascript
// Simple backend to save JSON data
const express = require('express');
const fs = require('fs');
const app = express();

app.use(express.json());

// Save projects
app.post('/api/projects', (req, res) => {
    fs.writeFileSync('data/projects.json', JSON.stringify(req.body, null, 2));
    res.json({ success: true });
});

// Get projects
app.get('/api/projects', (req, res) => {
    const data = fs.readFileSync('data/projects.json');
    res.json(JSON.parse(data));
});

app.listen(3000);
```

#### Option 2: Headless CMS Integration

Integrate with a headless CMS like:
- **Contentful** — Powerful, scalable, free tier available
- **Strapi** — Open-source, self-hosted
- **Sanity** — Real-time collaboration, excellent for portfolios

#### Option 3: Database-Backed CMS

Use a full-stack framework:
- **Next.js** — React-based, full-stack
- **Django** — Python-based, batteries included
- **Ruby on Rails** — Rapid development

---

## Advanced: Customizing the CMS

### Adding Custom Fields

To add a new field to projects:

1. **Edit `data/projects.json`** and add the field:
```json
{
  "id": "my-project",
  "title": "My Project",
  "customField": "Custom value"
}
```

2. **Update `admin/admin.js`** to include the field in the form:
```javascript
<div class="form-group">
    <label for="project-custom">Custom Field</label>
    <input type="text" id="project-custom" required>
</div>
```

3. **Update `cms-loader.js`** to render the field:
```javascript
// In renderProjectPage function
<p>${project.customField}</p>
```

### Adding New Content Types

To add a new content type (e.g., "Team Members"):

1. Create `data/team.json` with your data
2. Add a new section in `admin/index.html`
3. Add loading/rendering functions in `cms-loader.js`
4. Add admin management in `admin/admin.js`

---

## API Reference

### CMS Loader Functions

#### `loadCMSData()`
Loads all data from JSON files and renders the page.

#### `getProjectById(projectId)`
Returns a project object by ID.

#### `renderProjectPage(project)`
Renders a project page with all details.

#### `renderProjects()`
Renders the projects grid on the homepage.

#### `renderAwards()`
Renders the awards section.

#### `renderPublications()`
Renders the publications list.

#### `renderFooter()`
Renders the footer with site settings.

### Global Data Store

Access CMS data anywhere in your code:

```javascript
// Get all projects
console.log(window.cmsData.projects);

// Get specific project
const project = window.cmsData.projects.find(p => p.id === 'my-project');

// Get settings
console.log(window.cmsData.settings.email);
```

---

## Support & Resources

### Documentation Files

- `CMS-INTEGRATION-GUIDE.md` — Overview of CMS options
- `CMS-IMPLEMENTATION.md` — This file
- `admin/index.html` — Help section in admin dashboard

### Getting Help

1. Check the **Help** section in the admin dashboard
2. Review browser console for error messages (F12)
3. Check that JSON files are valid (use JSONLint.com)
4. Verify file permissions on your server

### Next Steps

1. **Customize** the CMS with your own data
2. **Set up** a backend for production
3. **Integrate** with a headless CMS if needed
4. **Deploy** to your hosting provider

---

## Deployment Checklist

- [ ] Update site settings (email, phone, location)
- [ ] Add all projects with images
- [ ] Add awards and publications
- [ ] Test all links and images
- [ ] Set up image hosting (Cloudinary, etc.)
- [ ] Back up your data
- [ ] Set up backend for production (if needed)
- [ ] Secure the admin dashboard (add authentication)
- [ ] Deploy to your hosting provider
- [ ] Test on live site
- [ ] Set up monitoring and analytics

---

## Questions?

For more information, see:
- `CMS-INTEGRATION-GUIDE.md` — CMS options and architecture
- `README.md` — General project documentation
- Admin dashboard Help section — Detailed usage instructions

Happy managing! 🎨
