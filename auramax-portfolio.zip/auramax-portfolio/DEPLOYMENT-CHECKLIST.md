# Deployment Checklist — Auramax Designs Portfolio

Use this checklist to ensure everything is ready before deploying to Netlify.

## Pre-Deployment Checks

### Content Review
- [ ] All project details are accurate and complete
- [ ] Project images are high quality and properly formatted
- [ ] Awards and publications are up to date
- [ ] Contact information is correct (email: hello@auramaxdesigns.com, phone: 0720382804)
- [ ] Studio location is accurate (Nairobi, Kenya)
- [ ] Social media links are correct (Instagram, LinkedIn)
- [ ] Tagline/description is compelling

### Functionality Testing
- [ ] Homepage loads correctly with hero image
- [ ] Project grid displays all projects
- [ ] Project cards show hover effects
- [ ] Project detail pages load when clicked
- [ ] Navigation links work correctly
- [ ] Footer displays all contact information
- [ ] Admin dashboard login works
- [ ] Can add/edit/delete projects in admin
- [ ] Settings can be updated in admin
- [ ] Awards and publications display correctly

### Admin Dashboard
- [ ] Login page is accessible at `/admin/login.html`
- [ ] Login credentials work: `hello@auramaxdesigns.com` / `@auramaxdesigns`
- [ ] Logout button appears and works
- [ ] Session management works correctly
- [ ] All admin functions are operational

### File Organization
- [ ] All HTML files are in root directory
- [ ] CSS files are in root directory
- [ ] JavaScript files are in root directory
- [ ] `admin/` folder contains all admin files
- [ ] `data/` folder contains JSON files
- [ ] `netlify.toml` is in root directory
- [ ] `_redirects` file is in root directory

### Image & Assets
- [ ] Logo image URL is correct and accessible
- [ ] Hero image loads properly
- [ ] All project images load correctly
- [ ] No broken image links
- [ ] Image URLs use HTTPS protocol

### Performance
- [ ] Page loads quickly (under 3 seconds)
- [ ] Images are optimized
- [ ] No console errors in browser (F12)
- [ ] No broken links
- [ ] Mobile responsive design works

## GitHub Setup

- [ ] GitHub account created
- [ ] New repository created: `auramax-portfolio`
- [ ] All portfolio files uploaded to GitHub
- [ ] Repository is public
- [ ] README file exists
- [ ] `.gitignore` is configured (if using Git CLI)

## Netlify Deployment

- [ ] Netlify account created
- [ ] GitHub connected to Netlify
- [ ] Repository selected for deployment
- [ ] Build settings configured:
  - [ ] Base directory: empty or `.`
  - [ ] Build command: empty
  - [ ] Publish directory: `.`
- [ ] Site deployed successfully
- [ ] Deployment URL provided

## Post-Deployment Testing

- [ ] Site loads at Netlify URL
- [ ] All pages are accessible
- [ ] Admin dashboard works on live site
- [ ] Can log in and edit content
- [ ] Changes persist after refresh
- [ ] Mobile view is responsive
- [ ] Desktop view looks correct
- [ ] Tablet view is optimized

## Custom Domain (Optional)

- [ ] Domain registered (if needed)
- [ ] Domain added to Netlify
- [ ] DNS settings updated
- [ ] HTTPS certificate installed
- [ ] Site accessible at custom domain
- [ ] Redirects work correctly

## Final Checks

- [ ] No sensitive information exposed
- [ ] Admin credentials are secure
- [ ] All links are working
- [ ] Contact information is clickable
- [ ] Social media links open correctly
- [ ] Analytics tracking is set up (if desired)
- [ ] Site is fast and responsive
- [ ] Browser compatibility verified

## Launch

- [ ] Site is live and accessible
- [ ] Share URL with clients/colleagues
- [ ] Test from different devices
- [ ] Monitor for any issues
- [ ] Keep admin credentials secure
- [ ] Plan for regular content updates

---

## Important Reminders

✓ **Backup Your Data** — Keep a local copy of your files
✓ **Update Regularly** — Add new projects and keep content fresh
✓ **Monitor Performance** — Check Netlify analytics
✓ **Security** — Keep your admin password secure
✓ **Testing** — Test on multiple devices and browsers

---

## Need Help?

If you encounter any issues:

1. Check the **NETLIFY-DEPLOYMENT.md** guide
2. Review **Netlify documentation** at docs.netlify.com
3. Check browser console for errors (F12)
4. Verify all files are uploaded correctly
5. Contact Netlify support if needed

**Good luck with your deployment! 🚀**
