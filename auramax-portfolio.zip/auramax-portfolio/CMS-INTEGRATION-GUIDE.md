# CMS Integration Guide — Auramax Designs Portfolio

This guide outlines multiple approaches to integrate a Content Management System (CMS) into your portfolio website, allowing you to update projects, awards, and content without editing HTML.

## Overview of CMS Options

### Option 1: Headless CMS (Recommended for Most Users)
**Best for:** Non-technical users who want a visual interface

Popular headless CMS platforms:
- **Contentful** — Powerful, flexible, free tier available
- **Strapi** — Open-source, self-hosted or managed
- **Sanity** — Real-time collaboration, excellent for portfolios
- **NetlifyCMS** — Git-based, free, integrates with Netlify hosting

**Pros:**
- Visual content editor (no coding required)
- Image management and optimization
- Version control and publishing workflows
- API-driven (decoupled from frontend)

**Cons:**
- May require subscription for advanced features
- Learning curve for setup
- Potential costs at scale

---

### Option 2: JSON-Based CMS (Built-in Solution)
**Best for:** Developers who want full control and simplicity

A lightweight JSON file stores all content, updated through a simple admin dashboard.

**Pros:**
- No external dependencies
- Full control over data structure
- Can be hosted anywhere
- Easy to backup and migrate
- Low cost (just hosting)

**Cons:**
- Limited to JSON data format
- Manual image hosting required
- Requires basic technical setup

---

### Option 3: Database-Backed CMS (Full-Stack)
**Best for:** Large portfolios with complex content

Uses a backend server (Node.js, Python) with a database (PostgreSQL, MongoDB).

**Pros:**
- Scalable to any size
- Advanced features (user roles, scheduling, etc.)
- Real-time updates
- Complex queries and filtering

**Cons:**
- More complex to set up and maintain
- Requires server hosting
- Higher ongoing costs
- More technical knowledge needed

---

### Option 4: Hybrid Approach (Recommended)
**Best for:** Balance of simplicity and functionality

Combine a headless CMS with your static site, or use a JSON-based system with image hosting.

---

## Recommended Solution: JSON-Based CMS with Admin Dashboard

For your portfolio, I recommend starting with a **JSON-based CMS** because:

1. ✓ Simple to implement and understand
2. ✓ No external service dependencies
3. ✓ Easy to backup and migrate
4. ✓ Can be upgraded to full-stack later
5. ✓ Perfect for portfolio-sized content (10-50 projects)

### Architecture

```
Frontend (Static HTML/CSS/JS)
    ↓
Fetch API
    ↓
CMS Data (JSON files)
    ↓
Admin Dashboard (Update JSON)
```

---

## Implementation: JSON-Based CMS

### File Structure

```
auramax-portfolio/
├── admin/
│   ├── index.html          # Admin dashboard
│   ├── admin.css           # Admin styling
│   └── admin.js            # Admin functionality
├── data/
│   ├── projects.json       # Project data
│   ├── awards.json         # Awards data
│   └── settings.json       # Site settings
├── index.html              # Homepage (dynamic)
├── project.html            # Project template (dynamic)
├── styles.css
├── script.js               # Data loading logic
└── README.md
```

### Data Structure

#### `data/projects.json`
```json
{
  "projects": [
    {
      "id": "luxury-kitchen",
      "title": "Luxury Kitchen Transformation",
      "type": "Residential",
      "year": 2024,
      "description": "A sophisticated culinary space...",
      "heroImage": "https://example.com/image.jpg",
      "gridImage": "https://example.com/image.jpg",
      "featured": true,
      "gridSize": "large",
      "overview": "This luxury kitchen...",
      "concept": "The kitchen was designed around...",
      "features": [
        {
          "title": "Concrete Gray Cabinetry",
          "description": "Custom-designed cabinetry..."
        }
      ],
      "materials": [
        {
          "element": "Cabinetry",
          "material": "Concrete composite",
          "finish": "Matte"
        }
      ]
    }
  ]
}
```

#### `data/awards.json`
```json
{
  "awards": [
    {
      "id": "award-1",
      "title": "International Design Excellence",
      "year": 2024,
      "organization": "Global Architecture & Design Awards"
    }
  ],
  "publications": [
    {
      "id": "pub-1",
      "title": "Minimalist Living Spaces",
      "publication": "Architectural Digest",
      "date": "March 2024"
    }
  ]
}
```

#### `data/settings.json`
```json
{
  "site": {
    "title": "Auramax Designs",
    "tagline": "Thoughtful spaces crafted with precision",
    "email": "hello@auramaxdesigns.com",
    "phone": "+254 (0) 123 456 789",
    "location": "Nairobi, Kenya",
    "logoUrl": "https://example.com/logo.png"
  }
}
```

---

## Step-by-Step Implementation

### Step 1: Create Admin Dashboard

The admin dashboard allows you to:
- View all projects, awards, and publications
- Add new projects
- Edit existing content
- Upload images
- Publish changes

### Step 2: Update Frontend to Use CMS Data

Modify the homepage to fetch and render data from JSON files:

```javascript
// Load projects from CMS
async function loadProjects() {
  const response = await fetch('/data/projects.json');
  const data = await response.json();
  renderProjects(data.projects);
}

function renderProjects(projects) {
  const grid = document.querySelector('.project-grid');
  grid.innerHTML = projects.map(project => `
    <article class="project-card project-card-${project.gridSize}">
      <div class="project-image">
        <img src="${project.gridImage}" alt="${project.title}">
      </div>
      <div class="project-info">
        <h3>${project.title}</h3>
        <p class="project-meta">${project.type} / ${project.year}</p>
        <p class="project-description">${project.description}</p>
        <a href="project.html?id=${project.id}" class="project-link">Explore the project</a>
      </div>
    </article>
  `).join('');
}

// Load on page load
document.addEventListener('DOMContentLoaded', loadProjects);
```

### Step 3: Create Dynamic Project Pages

Instead of separate HTML files for each project, use a template:

```html
<!-- project.html -->
<article class="case-study" id="project-content">
  <!-- Content loaded dynamically -->
</article>

<script>
async function loadProject() {
  const params = new URLSearchParams(window.location.search);
  const projectId = params.get('id');
  
  const response = await fetch('/data/projects.json');
  const data = await response.json();
  const project = data.projects.find(p => p.id === projectId);
  
  if (project) {
    renderProjectPage(project);
  }
}

function renderProjectPage(project) {
  const container = document.getElementById('project-content');
  container.innerHTML = `
    <div class="case-study-header">
      <h1>${project.title}</h1>
      <div class="case-study-meta">
        <span class="meta-item"><strong>Project Type:</strong> ${project.type}</span>
        <span class="meta-item"><strong>Completed:</strong> ${project.year}</span>
      </div>
    </div>
    <!-- ... more content ... -->
  `;
}

document.addEventListener('DOMContentLoaded', loadProject);
</script>
```

---

## Comparison: CMS Options

| Feature | JSON-Based | Headless CMS | Database-Backed |
|---------|-----------|-------------|-----------------|
| **Setup Time** | 1-2 hours | 2-4 hours | 4-8 hours |
| **Cost** | Free | Free-$100/mo | $10-100/mo |
| **Ease of Use** | Medium | Easy | Hard |
| **Scalability** | Up to 50 projects | Unlimited | Unlimited |
| **Image Management** | Manual | Built-in | Built-in |
| **Learning Curve** | Low | Medium | High |
| **Best For** | Small-medium portfolios | Non-technical users | Large/complex sites |

---

## Migration Path

If you start with JSON-based CMS and later need more features:

1. **Phase 1:** JSON-based CMS (current)
2. **Phase 2:** Add backend server (Node.js/Express)
3. **Phase 3:** Add database (PostgreSQL/MongoDB)
4. **Phase 4:** Migrate to full headless CMS if needed

All data can be exported and imported between systems.

---

## Recommended Next Steps

1. **Choose your CMS approach** based on your needs
2. **Implement the JSON-based solution** (I can build this for you)
3. **Create the admin dashboard** for easy content management
4. **Migrate existing content** to JSON format
5. **Update frontend** to load data dynamically
6. **Deploy and test** the complete system

---

## Popular Headless CMS Platforms

### Contentful
- **URL:** https://www.contentful.com
- **Pricing:** Free tier + paid plans
- **Best for:** Developers and agencies
- **Features:** Visual editor, API-first, webhooks

### Strapi
- **URL:** https://strapi.io
- **Pricing:** Open-source (free) or managed
- **Best for:** Developers who want full control
- **Features:** Customizable, self-hosted option

### Sanity
- **URL:** https://www.sanity.io
- **Pricing:** Free tier + paid plans
- **Best for:** Content teams and designers
- **Features:** Real-time collaboration, portable content

### NetlifyCMS
- **URL:** https://www.netlifycms.org
- **Pricing:** Free
- **Best for:** Static site generators
- **Features:** Git-based, no backend needed

---

## Next: Implementation

Would you like me to:
1. **Build the JSON-based CMS** with admin dashboard?
2. **Set up a Headless CMS** integration (Contentful/Strapi)?
3. **Create a hybrid solution** combining both approaches?

Let me know your preference and I'll implement it!
