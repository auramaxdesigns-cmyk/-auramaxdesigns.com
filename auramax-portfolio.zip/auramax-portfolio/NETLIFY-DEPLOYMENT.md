# Netlify Deployment Guide — Auramax Designs Portfolio

This guide walks you through deploying your Auramax Designs portfolio website to Netlify.

## Prerequisites

Before you start, make sure you have:

- A **GitHub account** (free at github.com)
- A **Netlify account** (free at netlify.com)
- Your portfolio files ready

## Step 1: Create a GitHub Repository

### 1.1 Go to GitHub
- Visit [github.com](https://github.com)
- Sign in to your account (or create one if needed)

### 1.2 Create a New Repository
- Click the **+** icon in the top right
- Select **New repository**
- Fill in the details:
  - **Repository name:** `auramax-portfolio` (or your preferred name)
  - **Description:** "Auramax Designs - Interior Design Portfolio"
  - **Visibility:** Public
  - **Initialize with:** Add a README file
- Click **Create repository**

### 1.3 Upload Your Files
You have two options:

**Option A: Upload via GitHub Web Interface (Easiest)**
1. Click **Add file** → **Upload files**
2. Drag and drop all your portfolio files
3. Write a commit message: "Initial portfolio setup"
4. Click **Commit changes**

**Option B: Use Git Command Line**
```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/auramax-portfolio.git
cd auramax-portfolio

# Copy your portfolio files into this directory
# Then commit and push
git add .
git commit -m "Initial portfolio setup"
git push origin main
```

### Files to Upload
Make sure you upload these folders and files:

```
├── index.html
├── index-dynamic.html
├── project-dynamic.html
├── styles.css
├── case-study.css
├── script.js
├── cms-loader.js
├── netlify.toml
├── _redirects
├── admin/
│   ├── index.html
│   ├── login.html
│   ├── admin.css
│   └── admin.js
└── data/
    ├── projects.json
    ├── awards.json
    └── settings.json
```

## Step 2: Deploy to Netlify

### 2.1 Connect Netlify to GitHub
1. Go to [netlify.com](https://netlify.com)
2. Sign in with GitHub (or create an account)
3. Click **Add new site** → **Import an existing project**
4. Select **GitHub** as your Git provider
5. Authorize Netlify to access your GitHub account

### 2.2 Select Your Repository
1. Search for your repository: `auramax-portfolio`
2. Click to select it
3. Netlify will show your repository details

### 2.3 Configure Build Settings
- **Base directory:** Leave empty (or `.`)
- **Build command:** Leave empty (no build needed)
- **Publish directory:** `.` (root directory)
- Click **Deploy site**

### 2.4 Wait for Deployment
- Netlify will deploy your site automatically
- You'll see a build log showing the progress
- Once complete, you'll get a temporary URL like: `https://your-site-name.netlify.app`

## Step 3: Set Up Your Custom Domain (Optional)

### 3.1 Add Custom Domain
1. In Netlify dashboard, go to **Site settings**
2. Click **Domain management**
3. Click **Add domain**
4. Enter your domain (e.g., `auramaxdesigns.com`)
5. Follow the instructions to update your domain DNS settings

### 3.2 Enable HTTPS
- Netlify automatically provides free SSL/HTTPS
- Go to **Site settings** → **Domain management**
- Verify that HTTPS is enabled

## Step 4: Test Your Deployed Site

### 4.1 Test the Homepage
- Visit your Netlify URL
- Check that the hero image loads
- Verify the project grid displays correctly
- Test the navigation links

### 4.2 Test the Admin Dashboard
- Go to `/admin/` on your deployed site
- Log in with:
  - **Email:** `hello@auramaxdesigns.com`
  - **Password:** `@auramaxdesigns`
- Test adding, editing, and deleting projects
- Verify changes appear on the homepage

### 4.3 Test Project Pages
- Click on a project in the grid
- Verify the project details page loads
- Check all images and text display correctly

### 4.4 Test Contact Information
- Scroll to the footer
- Verify email and phone number are correct
- Test email link (should open your email client)
- Test phone link (should open dialer on mobile)

## Step 5: Configure Automatic Deployments

### 5.1 Enable Auto-Deploy
- In Netlify dashboard, go to **Deployments**
- Click **Deployment settings**
- Ensure "Auto publish" is enabled
- Now, every time you push to GitHub, your site updates automatically!

### 5.2 Update Your Site
To make changes after deployment:

1. Edit your files locally or on GitHub
2. Commit and push changes to GitHub
3. Netlify automatically deploys the changes
4. Your site updates within minutes

## Important Notes

### Data Persistence
- Your CMS data (projects, awards, settings) is stored in JSON files
- When you edit through the admin dashboard, changes are saved locally
- **To persist changes across deployments:**
  - Download your updated `data/` folder
  - Upload it to your GitHub repository
  - Commit the changes
  - Netlify will redeploy with your updated data

### Admin Dashboard Security
- The admin dashboard is protected with login credentials
- Credentials are checked client-side (browser-based)
- **For production:** Consider adding server-side authentication
- Keep your password secure and don't share it

### Performance Tips
- Images are cached for 1 year (immutable)
- Admin and data files are cached for shorter periods
- Netlify provides CDN distribution for fast loading worldwide

## Troubleshooting

### Site Shows 404 Error
- Check that `netlify.toml` is in your root directory
- Verify `_redirects` file exists
- Ensure all HTML files are uploaded

### Admin Dashboard Won't Load
- Clear browser cache (Ctrl+Shift+Delete)
- Check browser console for errors (F12)
- Verify `admin/` folder and files are uploaded

### Changes Don't Appear After Editing
- Wait 2-3 minutes for Netlify to redeploy
- Hard refresh your browser (Ctrl+Shift+R)
- Check the Netlify deploy log for errors

### Images Not Loading
- Verify image URLs in your JSON files are correct
- Check that external image services are accessible
- Use absolute URLs (starting with https://)

## Support & Help

- **Netlify Docs:** https://docs.netlify.com
- **Netlify Support:** https://support.netlify.com
- **GitHub Help:** https://docs.github.com

## Next Steps

1. ✅ Create GitHub repository
2. ✅ Upload portfolio files
3. ✅ Deploy to Netlify
4. ✅ Test all functionality
5. ✅ Set up custom domain (optional)
6. ✅ Configure auto-deployments
7. ✅ Share your live site!

---

**Your site is now live and ready to showcase your interior design work!** 🎉

For questions or issues, refer to the Netlify documentation or contact Netlify support.
