// AURAMAX DESIGNS — ADMIN DASHBOARD
// CMS Interface for managing portfolio content

// State
let projectsData = [];
let awardsData = [];
let publicationsData = [];
let settingsData = {};
let editingProjectId = null;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadAllData();
    setupEventListeners();
});

// Event Listeners
function setupEventListeners() {
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to logout?')) {
                sessionStorage.removeItem('auramaxAdminSession');
                sessionStorage.removeItem('auramaxAdminSessionExpiry');
                window.location.href = 'login.html';
            }
        });
    }

    // Navigation
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.addEventListener('click', function() {
            switchSection(this.dataset.section);
        });
    });

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });

    // Project Modal
    document.getElementById('add-project-btn').addEventListener('click', openProjectModal);
    document.getElementById('project-form').addEventListener('submit', saveProject);
    document.getElementById('cancel-btn').addEventListener('click', closeProjectModal);

    // Award Modal
    document.getElementById('add-award-btn').addEventListener('click', openAwardModal);
    document.getElementById('award-form').addEventListener('submit', saveAward);
    document.getElementById('cancel-award-btn').addEventListener('click', closeAwardModal);

    // Publication Modal
    document.getElementById('add-publication-btn').addEventListener('click', openPublicationModal);
    document.getElementById('publication-form').addEventListener('submit', savePublication);
    document.getElementById('cancel-publication-btn').addEventListener('click', closePublicationModal);

    // Modal Close
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.modal').classList.remove('show');
        });
    });

    // Settings Form
    document.getElementById('settings-form').addEventListener('submit', saveSettings);
}

// Load Data
async function loadAllData() {
    try {
        // Load projects
        const projectsResponse = await fetch('../data/projects.json');
        const projectsJson = await projectsResponse.json();
        projectsData = projectsJson.projects;

        // Load awards
        const awardsResponse = await fetch('../data/awards.json');
        const awardsJson = await awardsResponse.json();
        awardsData = awardsJson.awards;
        publicationsData = awardsJson.publications;

        // Load settings
        const settingsResponse = await fetch('../data/settings.json');
        const settingsJson = await settingsResponse.json();
        settingsData = settingsJson.site;

        // Render all sections
        renderProjects();
        renderAwards();
        renderPublications();
        renderSettings();
    } catch (error) {
        console.error('Error loading data:', error);
        alert('Error loading data. Please check the console.');
    }
}

// Section Switching
function switchSection(section) {
    // Update nav
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-section="${section}"]`).classList.add('active');

    // Update content
    document.querySelectorAll('.admin-section').forEach(sec => {
        sec.classList.remove('active');
    });
    document.getElementById(`${section}-section`).classList.add('active');
}

// Tab Switching
function switchTab(tab) {
    // Update tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tab).classList.add('active');
}

// Projects
function renderProjects() {
    const list = document.getElementById('projects-list');
    list.innerHTML = projectsData.map(project => `
        <div class="project-card">
            <div class="project-card-image">
                <img src="${project.gridImage}" alt="${project.title}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 dy=%22.3em%22 fill=%22%23999%22%3EImage not found%3C/text%3E%3C/svg%3E'">
            </div>
            <div class="project-card-content">
                <div class="project-card-title">${project.title}</div>
                <div class="project-card-meta">${project.type} / ${project.year}</div>
                <div class="project-card-actions">
                    <button class="btn btn-primary btn-small" onclick="editProject('${project.id}')">Edit</button>
                    <button class="btn btn-danger btn-small" onclick="deleteProject('${project.id}')">Delete</button>
                </div>
            </div>
        </div>
    `).join('');
}

function openProjectModal(projectId = null) {
    editingProjectId = projectId;
    const modal = document.getElementById('project-modal');
    const form = document.getElementById('project-form');

    if (projectId) {
        const project = projectsData.find(p => p.id === projectId);
        document.getElementById('modal-title').textContent = 'Edit Project';
        document.getElementById('project-id').value = project.id;
        document.getElementById('project-id').disabled = true;
        document.getElementById('project-title').value = project.title;
        document.getElementById('project-type').value = project.type;
        document.getElementById('project-year').value = project.year;
        document.getElementById('project-description').value = project.description;
        document.getElementById('project-hero-image').value = project.heroImage;
        document.getElementById('project-grid-image').value = project.gridImage;
        document.getElementById('project-grid-size').value = project.gridSize;
        document.getElementById('project-featured').checked = project.featured;
        document.getElementById('project-overview').value = project.overview;
        document.getElementById('project-concept').value = project.concept;
        document.getElementById('project-outcome').value = project.outcome;
    } else {
        document.getElementById('modal-title').textContent = 'Add New Project';
        document.getElementById('project-id').disabled = false;
        form.reset();
    }

    modal.classList.add('show');
}

function closeProjectModal() {
    document.getElementById('project-modal').classList.remove('show');
    editingProjectId = null;
}

function saveProject(e) {
    e.preventDefault();

    const project = {
        id: document.getElementById('project-id').value,
        title: document.getElementById('project-title').value,
        type: document.getElementById('project-type').value,
        year: parseInt(document.getElementById('project-year').value),
        description: document.getElementById('project-description').value,
        heroImage: document.getElementById('project-hero-image').value,
        gridImage: document.getElementById('project-grid-image').value,
        featured: document.getElementById('project-featured').checked,
        gridSize: document.getElementById('project-grid-size').value,
        overview: document.getElementById('project-overview').value,
        concept: document.getElementById('project-concept').value,
        outcome: document.getElementById('project-outcome').value,
        features: [],
        materials: []
    };

    if (editingProjectId) {
        const index = projectsData.findIndex(p => p.id === editingProjectId);
        projectsData[index] = { ...projectsData[index], ...project };
    } else {
        projectsData.push(project);
    }

    saveProjectsToFile();
    renderProjects();
    closeProjectModal();
    alert('Project saved successfully!');
}

function editProject(projectId) {
    openProjectModal(projectId);
}

function deleteProject(projectId) {
    if (confirm('Are you sure you want to delete this project?')) {
        projectsData = projectsData.filter(p => p.id !== projectId);
        saveProjectsToFile();
        renderProjects();
        alert('Project deleted successfully!');
    }
}

function saveProjectsToFile() {
    // In a real application, this would send data to a backend
    // For now, we'll store it in localStorage as a demo
    localStorage.setItem('auramaxProjects', JSON.stringify({ projects: projectsData }));
    console.log('Projects saved to localStorage:', projectsData);
}

// Awards
function renderAwards() {
    const list = document.getElementById('awards-list');
    list.innerHTML = awardsData.map(award => `
        <div class="award-item">
            <div class="award-item-content">
                <div class="award-item-title">${award.title}</div>
                <div class="award-item-meta">${award.year} • ${award.organization}</div>
            </div>
            <div class="award-item-actions">
                <button class="btn btn-primary btn-small" onclick="editAward('${award.id}')">Edit</button>
                <button class="btn btn-danger btn-small" onclick="deleteAward('${award.id}')">Delete</button>
            </div>
        </div>
    `).join('');
}

function openAwardModal(awardId = null) {
    const modal = document.getElementById('award-modal');
    const form = document.getElementById('award-form');

    if (awardId) {
        const award = awardsData.find(a => a.id === awardId);
        document.getElementById('award-title').value = award.title;
        document.getElementById('award-year').value = award.year;
        document.getElementById('award-organization').value = award.organization;
        form.dataset.awardId = awardId;
    } else {
        form.reset();
        delete form.dataset.awardId;
    }

    modal.classList.add('show');
}

function closeAwardModal() {
    document.getElementById('award-modal').classList.remove('show');
}

function saveAward(e) {
    e.preventDefault();

    const award = {
        id: this.dataset.awardId || 'award-' + Date.now(),
        title: document.getElementById('award-title').value,
        year: parseInt(document.getElementById('award-year').value),
        organization: document.getElementById('award-organization').value
    };

    if (this.dataset.awardId) {
        const index = awardsData.findIndex(a => a.id === this.dataset.awardId);
        awardsData[index] = award;
    } else {
        awardsData.push(award);
    }

    saveAwardsToFile();
    renderAwards();
    closeAwardModal();
    alert('Award saved successfully!');
}

function editAward(awardId) {
    openAwardModal(awardId);
}

function deleteAward(awardId) {
    if (confirm('Are you sure you want to delete this award?')) {
        awardsData = awardsData.filter(a => a.id !== awardId);
        saveAwardsToFile();
        renderAwards();
        alert('Award deleted successfully!');
    }
}

function saveAwardsToFile() {
    localStorage.setItem('auramaxAwards', JSON.stringify({ awards: awardsData }));
    console.log('Awards saved to localStorage:', awardsData);
}

// Publications
function renderPublications() {
    const list = document.getElementById('publications-list');
    list.innerHTML = publicationsData.map(pub => `
        <div class="publication-item">
            <div class="publication-item-content">
                <div class="publication-item-title">${pub.title}</div>
                <div class="publication-item-meta">${pub.publication} • ${pub.date}</div>
            </div>
            <div class="publication-item-actions">
                <button class="btn btn-primary btn-small" onclick="editPublication('${pub.id}')">Edit</button>
                <button class="btn btn-danger btn-small" onclick="deletePublication('${pub.id}')">Delete</button>
            </div>
        </div>
    `).join('');
}

function openPublicationModal(pubId = null) {
    const modal = document.getElementById('publication-modal');
    const form = document.getElementById('publication-form');

    if (pubId) {
        const pub = publicationsData.find(p => p.id === pubId);
        document.getElementById('publication-title').value = pub.title;
        document.getElementById('publication-name').value = pub.publication;
        document.getElementById('publication-date').value = pub.date;
        form.dataset.pubId = pubId;
    } else {
        form.reset();
        delete form.dataset.pubId;
    }

    modal.classList.add('show');
}

function closePublicationModal() {
    document.getElementById('publication-modal').classList.remove('show');
}

function savePublication(e) {
    e.preventDefault();

    const pub = {
        id: this.dataset.pubId || 'pub-' + Date.now(),
        title: document.getElementById('publication-title').value,
        publication: document.getElementById('publication-name').value,
        date: document.getElementById('publication-date').value
    };

    if (this.dataset.pubId) {
        const index = publicationsData.findIndex(p => p.id === this.dataset.pubId);
        publicationsData[index] = pub;
    } else {
        publicationsData.push(pub);
    }

    savePublicationsToFile();
    renderPublications();
    closePublicationModal();
    alert('Publication saved successfully!');
}

function editPublication(pubId) {
    openPublicationModal(pubId);
}

function deletePublication(pubId) {
    if (confirm('Are you sure you want to delete this publication?')) {
        publicationsData = publicationsData.filter(p => p.id !== pubId);
        savePublicationsToFile();
        renderPublications();
        alert('Publication deleted successfully!');
    }
}

function savePublicationsToFile() {
    localStorage.setItem('auramaxPublications', JSON.stringify({ publications: publicationsData }));
    console.log('Publications saved to localStorage:', publicationsData);
}

// Settings
function renderSettings() {
    const form = document.getElementById('settings-form');
    form.innerHTML = `
        <div class="form-group">
            <label for="site-title">Site Title</label>
            <input type="text" id="site-title" value="${settingsData.title || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-tagline">Tagline</label>
            <input type="text" id="site-tagline" value="${settingsData.tagline || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-email">Email</label>
            <input type="email" id="site-email" value="${settingsData.email || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-phone">Phone</label>
            <input type="tel" id="site-phone" value="${settingsData.phone || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-location">Location</label>
            <input type="text" id="site-location" value="${settingsData.location || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-region">Region</label>
            <input type="text" id="site-region" value="${settingsData.region || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-logo">Logo URL</label>
            <input type="url" id="site-logo" value="${settingsData.logoUrl || ''}" required>
        </div>
        <div class="form-group">
            <label for="site-instagram">Instagram URL</label>
            <input type="url" id="site-instagram" value="${settingsData.social?.instagram || ''}">
        </div>
        <div class="form-group">
            <label for="site-linkedin">LinkedIn URL</label>
            <input type="url" id="site-linkedin" value="${settingsData.social?.linkedin || ''}">
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save Settings</button>
        </div>
    `;
    form.addEventListener('submit', saveSettings);
}

function saveSettings(e) {
    e.preventDefault();

    settingsData = {
        title: document.getElementById('site-title').value,
        tagline: document.getElementById('site-tagline').value,
        email: document.getElementById('site-email').value,
        phone: document.getElementById('site-phone').value,
        location: document.getElementById('site-location').value,
        region: document.getElementById('site-region').value,
        logoUrl: document.getElementById('site-logo').value,
        social: {
            instagram: document.getElementById('site-instagram').value,
            linkedin: document.getElementById('site-linkedin').value
        }
    };

    localStorage.setItem('auramaxSettings', JSON.stringify({ site: settingsData }));
    console.log('Settings saved to localStorage:', settingsData);
    alert('Settings saved successfully!');
}

// Note: In a production environment, you would send data to a backend server
// instead of using localStorage. This demo uses localStorage for simplicity.
