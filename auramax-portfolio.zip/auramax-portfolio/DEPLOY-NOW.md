# Deploy to Netlify Now — Step-by-Step

Your Auramax Designs portfolio is ready to deploy! Follow these simple steps to get your site live.

## What's Ready

✓ All HTML pages
✓ Admin dashboard with login (auramaxdesigns@gmail.com)
✓ CMS with projects, awards, and settings
✓ Updated contact email: auramaxdesigns@gmail.com
✓ Netlify configuration files
✓ All styling and scripts

## Files Included

```
auramax-portfolio/
├── index.html                    # Static homepage
├── index-dynamic.html            # CMS-powered homepage
├── project-dynamic.html          # Dynamic project pages
├── styles.css                    # Main styles
├── case-study.css               # Project page styles
├── script.js                     # Interactive features
├── cms-loader.js                # CMS functionality
├── netlify.toml                 # Netlify configuration
├── _redirects                   # URL routing
├── admin/
│   ├── index.html              # Admin dashboard
│   ├── login.html              # Login page
│   ├── admin.css               # Admin styles
│   └── admin.js                # Admin functionality
└── data/
    ├── projects.json           # Project data
    ├── awards.json             # Awards data
    └── settings.json           # Site settings
```

## Deployment Steps

### Step 1: Create GitHub Repository (2 minutes)

1. Go to **[github.com/new](https://github.com/new)**
2. Enter repository name: `auramax-portfolio`
3. Add description: "Auramax Designs - Interior Design Portfolio"
4. Select **Public**
5. Click **Create repository**

### Step 2: Upload Files to GitHub (3 minutes)

**Option A: Web Upload (Easiest)**

1. In your new repository, click **Add file** → **Upload files**
2. Download all files from `/home/ubuntu/webdev-projects/auramax-portfolio/`
3. Drag and drop them into GitHub
4. Write commit message: "Initial portfolio deployment"
5. Click **Commit changes**

**Option B: Command Line**

```bash
# Clone repository
git clone https://github.com/YOUR_USERNAME/auramax-portfolio.git
cd auramax-portfolio

# Copy all portfolio files here
# Then push to GitHub
git add .
git commit -m "Initial portfolio deployment"
git push origin main
```

### Step 3: Deploy to Netlify (2 minutes)

1. Go to **[netlify.com](https://netlify.com)**
2. Sign in with GitHub (or create account)
3. Click **Add new site** → **Import an existing project**
4. Select **GitHub** as provider
5. Find and click `auramax-portfolio` repository
6. Review settings:
   - Base directory: (leave empty)
   - Build command: (leave empty)
   - Publish directory: `.`
7. Click **Deploy site**

### Step 4: Wait for Deployment (1-2 minutes)

Netlify will:
- Build your site
- Deploy to their servers
- Provide a live URL

You'll see a message like:
```
✓ Site deployed
Your site is live at: https://your-site-name.netlify.app
```

## Test Your Live Site

Once deployed, test these features:

**Homepage:**
- [ ] Hero image loads
- [ ] Project grid displays
- [ ] Navigation works
- [ ] Footer shows correct email: auramaxdesigns@gmail.com
- [ ] Footer shows correct phone: 0720382804

**Admin Dashboard:**
- [ ] Go to `/admin/`
- [ ] Log in with:
  - Email: `auramaxdesigns@gmail.com`
  - Password: `@auramaxdesigns`
- [ ] Can view projects
- [ ] Can add/edit/delete projects
- [ ] Can update settings

**Project Pages:**
- [ ] Click a project in grid
- [ ] Project details page loads
- [ ] Images display correctly
- [ ] Back to homepage works

**Responsive Design:**
- [ ] Test on mobile (375px width)
- [ ] Test on tablet (768px width)
- [ ] Test on desktop (1200px width)

## Your Live Site Details

Once deployed, you'll have:

| Item | Details |
|------|---------|
| **Live URL** | `https://your-site-name.netlify.app` |
| **Admin URL** | `https://your-site-name.netlify.app/admin/` |
| **Admin Email** | `auramaxdesigns@gmail.com` |
| **Admin Password** | `@auramaxdesigns` |
| **HTTPS** | Automatic (free) |
| **CDN** | Global distribution |

## Optional: Set Up Custom Domain

To use your own domain (e.g., auramaxdesigns.com):

1. Buy domain from registrar (GoDaddy, Namecheap, etc.)
2. In Netlify: **Site settings** → **Domain management**
3. Click **Add domain**
4. Enter your domain
5. Follow DNS setup instructions
6. Wait 24-48 hours for DNS propagation

## Update Your Site After Deployment

To make changes after going live:

1. Edit files locally or on GitHub
2. Commit and push changes
3. Netlify automatically redeploys (2-3 minutes)
4. Your site updates automatically!

## Troubleshooting

**404 Error on site?**
- Verify `netlify.toml` and `_redirects` are uploaded
- Check Netlify deploy logs for errors

**Admin won't load?**
- Clear browser cache (Ctrl+Shift+Delete)
- Hard refresh (Ctrl+Shift+R)
- Check browser console (F12)

**Images not showing?**
- Verify image URLs are correct
- Check they use HTTPS protocol

**Need help?**
- Read: NETLIFY-DEPLOYMENT.md (detailed guide)
- Visit: https://docs.netlify.com
- Contact: Netlify support

## Next Steps

1. ✅ Create GitHub repository
2. ✅ Upload all files
3. ✅ Deploy to Netlify
4. ✅ Test your live site
5. ✅ Share your portfolio!

---

## Quick Reference

**Your Admin Credentials:**
```
Email: auramaxdesigns@gmail.com
Password: @auramaxdesigns
```

**Important Files:**
- `netlify.toml` — Netlify configuration
- `_redirects` — URL routing
- `data/settings.json` — Contact info
- `admin/login.html` — Admin login

---

**Your portfolio is ready to launch! 🚀**

Follow the steps above and your site will be live within minutes.

Good luck! 🎉
