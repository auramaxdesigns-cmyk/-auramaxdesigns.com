# Trevor Kiprono Portfolio — Design Direction

## Three Stylistic Approaches

### 1. **Brutalist Minimalism**
A raw, unpolished aesthetic inspired by brutalist architecture. Exposed typography, stark contrasts, and minimal ornamentation. Heavy use of concrete grays and pure blacks with occasional warm wood accents as punctuation.
**Probability: 0.07**

### 2. **Scandinavian Serenity**
Clean, light-filled spaces with breathing room. Soft grays, natural materials, and understated elegance. Emphasizes negative space and subtle transitions.
**Probability: 0.04**

### 3. **Contemporary Luxury**
Sophisticated dark mode with warm accents. Deep charcoal backgrounds, refined typography, and strategic use of gold or warm wood tones. Feels premium and intentional.
**Probability: 0.08**

---

## Selected Approach: **Brutalist Minimalism**

This approach aligns perfectly with the interior design portfolio's need to showcase architectural projects with dramatic impact while maintaining a professional, gallery-like presentation.

### Design Movement
**Brutalism meets Digital Minimalism** — inspired by 1960s-70s brutalist architecture (raw concrete, bold forms, honest materials) translated into contemporary web design with extreme restraint and typographic dominance.

### Core Principles
1. **Radical Simplicity**: Every element must justify its existence. No decorative flourishes.
2. **Material Honesty**: Concrete gray (#3a3a3a), pure white, and warm wood (#8b6f47) are the only colors. They represent the materials of interior design.
3. **Typographic Authority**: Typography is the primary design element. Large, bold headlines create hierarchy and drama.
4. **Negative Space as Content**: Generous whitespace (or dark space) creates breathing room and emphasizes project visuals.

### Color Philosophy
- **Concrete Gray (#3a3a3a)**: The dominant background, representing raw materials and architectural honesty.
- **Pure White (#ffffff)**: For text and accents, creating stark contrast and clarity.
- **Warm Wood (#8b6f47)**: Accent color for interactive elements, links, and subtle highlights—representing the warmth of interior spaces.
- **Off-Black (#1a1a1a)**: Used for text on light backgrounds and deepest shadows.

The palette is intentionally restrained. These three colors are enough to create visual hierarchy, guide attention, and convey sophistication without distraction.

### Layout Paradigm
**Asymmetrical Grid with Dramatic Breathing**
- Hero section: Full-bleed project image with minimal text overlay (firm name, tagline).
- Project grid: Staggered, not uniform. Some projects span 2 columns, others 1. Creates visual rhythm.
- Case study pages: Generous margins (15-20% on sides). Images breathe. Text is left-aligned, never centered.
- Avoid centered layouts entirely—they dilute the brutalist aesthetic.

### Signature Elements
1. **Bold Dividing Lines**: Thin, full-width horizontal lines (1-2px, warm wood color) separate sections. They're architectural and minimal.
2. **Large Serif Headings**: Serif typography (e.g., Georgia, Playfair Display) for project titles and section headers. Creates gravitas.
3. **Minimal Icons/Marks**: The Auramax logo (organic leaf motif) appears small in the header and footer. No other decorative icons.

### Interaction Philosophy
- **Hover States**: Project cards reveal a thin warm wood underline or border on hover. No color fills, no animations.
- **Transitions**: Subtle 200ms fade-ins when scrolling into view. No bounces or playful animations—everything is restrained.
- **Links**: Warm wood color (#8b6f47) with underline on hover. No color change.
- **Buttons**: Minimal borders (warm wood) with white text. On hover, background becomes warm wood, text becomes dark gray.

### Animation
- **Entrance Animations**: Images fade in subtly (200-300ms) as they come into viewport. Text fades in with a slight delay.
- **Scroll Triggers**: Project cards fade in from bottom (50px) as user scrolls. No parallax or complex effects.
- **Hover Effects**: Smooth 150ms transitions on all interactive elements. No scale transforms—only opacity and color changes.
- **Page Transitions**: Fade to dark gray, load new page content, fade in. No sliding or spinning.

### Typography System
- **Headings**: Serif font (Playfair Display or similar). Sizes: H1 (4rem), H2 (2.5rem), H3 (1.5rem).
- **Body Text**: Sans-serif (Inter or similar). Size: 1rem (16px), line-height: 1.6.
- **Captions/Metadata**: Sans-serif, 0.875rem, warm wood color or light gray.
- **Hierarchy Rule**: Serif = importance, Sans-serif = supporting information.

### Brand Essence
**Thoughtful spaces crafted with precision.** For architects and interior designers who value substance over style. Different because it prioritizes the work over the designer.

**Personality Adjectives**: Refined, Honest, Intentional.

### Brand Voice
Headlines and CTAs sound authoritative but not pretentious. Microcopy is direct and clear.
- Example headline: "Residential Transformation: A Study in Spatial Flow"
- Example CTA: "Explore the project" (not "Click here" or "Discover more")
- Tone: Professional, thoughtful, never salesy or casual.

### Wordmark & Logo
The **Auramax logo** (organic leaf motif in a circle) is used as-is. It's distinctive and already embodies the brand's philosophy. Placed in the header (small, ~40px) and footer (medium, ~60px). Never enlarged or modified.

### Signature Brand Color
**Warm Wood (#8b6f47)** — an ownable accent that appears in links, hover states, dividing lines, and button borders. It's warm enough to feel human, but restrained enough to maintain the brutalist aesthetic.

---

## Implementation Commitment
This design will be executed with absolute fidelity to the brutalist minimalism philosophy. Every design decision will be evaluated against: "Does this reinforce material honesty, typographic authority, and radical simplicity?"
